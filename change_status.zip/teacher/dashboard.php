<?php
// Start session
session_start();

// Check if user is logged in, redirect if not
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root"; // Change as per your configuration
$password = ""; // Change as per your configuration
$dbname = "paper_archive"; // Change to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle file upload
if(isset($_POST['upload'])) {
    $title = $_POST['title'];
    $department = $_POST['department'];
    $course_code = $_POST['course_code'];
    $paper_year = $_POST['paper_year'];
    $semester = $_POST['semester'];
    $subject = $_POST['subject'];
    $credit = $_POST['credit'];
    
    // Check if same title, semester and subject combination already exists
    $check_duplicate = "SELECT * FROM question_papers WHERE title = '$title' AND semester = '$semester' AND subject = '$subject' AND department = '$department' AND course_code = '$course_code' AND paper_year = '$paper_year'";
    $duplicate_result = $conn->query($check_duplicate);
    
    if($duplicate_result->num_rows > 0) {
        $upload_error = "A question paper with the same details already exists.";
    } else {
        // File upload handling
        $target_dir = "../uploads/question_papers/";
        
        // Create directory if it doesn't exist
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        $file_name = basename($_FILES["question_paper"]["name"]);
        $target_file = $target_dir . time() . "_" . $file_name;
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        
        // Check if file is a PDF
        if($file_type != "pdf") {
            $upload_error = "Sorry, only PDF files are allowed.";
        } else {
            // Upload file
            if (move_uploaded_file($_FILES["question_paper"]["tmp_name"], $target_file)) {
                // Insert into database
                $sql = "INSERT INTO question_papers (title, department, course_code, paper_year, semester, subject, credit, file_path) 
                        VALUES ('$title', '$department', '$course_code', '$paper_year', '$semester', '$subject', '$credit', '$target_file')";
                
                if ($conn->query($sql) === TRUE) {
                    $upload_success = "Question paper has been uploaded successfully.";
                } else {
                    $upload_error = "Error: " . $sql . "<br>" . $conn->error;
                }
            } else {
                $upload_error = "Sorry, there was an error uploading your file.";
            }
        }
    }
}

// Get list of filters
$semester_query = "SELECT DISTINCT semester FROM question_papers ORDER BY semester";
$semester_result = $conn->query($semester_query);

$subject_query = "SELECT DISTINCT subject FROM question_papers ORDER BY subject";
$subject_result = $conn->query($subject_query);

$department_query = "SELECT DISTINCT department FROM question_papers ORDER BY department";
$department_result = $conn->query($department_query);

$year_query = "SELECT DISTINCT paper_year FROM question_papers ORDER BY paper_year DESC";
$year_result = $conn->query($year_query);

// Handle filters
$filter_semester = isset($_GET['filter_semester']) ? $_GET['filter_semester'] : '';
$filter_subject = isset($_GET['filter_subject']) ? $_GET['filter_subject'] : '';
$filter_department = isset($_GET['filter_department']) ? $_GET['filter_department'] : '';
$filter_year = isset($_GET['filter_year']) ? $_GET['filter_year'] : '';

// Query to get question papers with filters
$query = "SELECT * FROM question_papers WHERE 1=1";

if (!empty($filter_semester)) {
    $query .= " AND semester = '$filter_semester'";
}

if (!empty($filter_subject)) {
    $query .= " AND subject = '$filter_subject'";
}

if (!empty($filter_department)) {
    $query .= " AND department = '$filter_department'";
}

if (!empty($filter_year)) {
    $query .= " AND paper_year = '$filter_year'";
}

$query .= " ORDER BY uploaded_at DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard - Question Papers</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.min.css">
    <style>
        .dashboard-container {
            padding: 30px;
        }
        .filter-section {
            margin-bottom: 20px;
        }
        .table-responsive {
            margin-top: 20px;
        }
        .upload-section {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 30px;
        }
        .no-papers {
            padding: 30px;
            text-align: center;
            background-color: #f8f9fa;
            border-radius: 5px;
        }
        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Question Paper Archive</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="#">Dashboard</a>
                    </li>
                </ul>
                <div class="d-flex">
                    <span class="navbar-text me-3">
                        Welcome, <?php echo htmlspecialchars($_SESSION['username'] ?? 'Teacher'); ?>
                    </span>
                    <a href="../logout.php" class="btn btn-danger btn-sm">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container dashboard-container">
        <div class="header-section">
            <h1>Teacher Dashboard - Question Papers</h1>
        </div>
        
        <!-- Upload Section -->
        <div class="upload-section">
            <h3>Upload New Question Paper</h3>
            
            <?php if(isset($upload_success)): ?>
                <div class="alert alert-success"><?php echo $upload_success; ?></div>
            <?php endif; ?>
            
            <?php if(isset($upload_error)): ?>
                <div class="alert alert-danger"><?php echo $upload_error; ?></div>
            <?php endif; ?>
            
            <form method="post" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="title" class="form-label">Paper Title</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="department" class="form-label">Department</label>
                        <input type="text" class="form-control" id="department" name="department" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <label for="course_code" class="form-label">Course Code</label>
                        <input type="text" class="form-control" id="course_code" name="course_code" required>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="subject" class="form-label">Subject</label>
                        <input type="text" class="form-control" id="subject" name="subject" required>
                    </div>
                    <div class="col-md-2 mb-3">
                        <label for="paper_year" class="form-label">Year</label>
                        <input type="number" class="form-control" id="paper_year" name="paper_year" min="2000" max="<?php echo date('Y'); ?>" value="<?php echo date('Y'); ?>" required>
                    </div>
                    <div class="col-md-2 mb-3">
                        <label for="semester" class="form-label">Semester</label>
                        <select class="form-select" id="semester" name="semester" required>
                            <option value="">Select</option>
                            <option value="Semester 1">Semester 1</option>
                            <option value="Semester 2">Semester 2</option>
                            <option value="Semester 3">Semester 3</option>
                            <option value="Semester 4">Semester 4</option>
                            <option value="Semester 5">Semester 5</option>
                            <option value="Semester 6">Semester 6</option>
                            <option value="Semester 7">Semester 7</option>
                            <option value="Semester 8">Semester 8</option>
                        </select>
                    </div>
                    <div class="col-md-2 mb-3">
                        <label for="credit" class="form-label">Credits</label>
                        <input type="number" class="form-control" id="credit" name="credit" min="1" max="10" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="question_paper" class="form-label">Question Paper (PDF only)</label>
                    <input type="file" class="form-control" id="question_paper" name="question_paper" accept=".pdf" required>
                </div>
                <button type="submit" name="upload" class="btn btn-primary">Upload Question Paper</button>
            </form>
        </div>
        
        <!-- Filter Section -->
        <div class="filter-section">
            <h3>View Question Papers</h3>
            <form method="get" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Department</label>
                    <select class="form-select" name="filter_department">
                        <option value="">All Departments</option>
                        <?php while($department_result && $department_row = $department_result->fetch_assoc()): ?>
                            <option value="<?php echo $department_row['department']; ?>" <?php echo ($filter_department == $department_row['department']) ? 'selected' : ''; ?>>
                                <?php echo $department_row['department']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Year</label>
                    <select class="form-select" name="filter_year">
                        <option value="">All Years</option>
                        <?php while($year_result && $year_row = $year_result->fetch_assoc()): ?>
                            <option value="<?php echo $year_row['paper_year']; ?>" <?php echo ($filter_year == $year_row['paper_year']) ? 'selected' : ''; ?>>
                                <?php echo $year_row['paper_year']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Semester</label>
                    <select class="form-select" name="filter_semester">
                        <option value="">All Semesters</option>
                        <?php while($semester_result && $semester_row = $semester_result->fetch_assoc()): ?>
                            <option value="<?php echo $semester_row['semester']; ?>" <?php echo ($filter_semester == $semester_row['semester']) ? 'selected' : ''; ?>>
                                <?php echo $semester_row['semester']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Subject</label>
                    <select class="form-select" name="filter_subject">
                        <option value="">All Subjects</option>
                        <?php while($subject_result && $subject_row = $subject_result->fetch_assoc()): ?>
                            <option value="<?php echo $subject_row['subject']; ?>" <?php echo ($filter_subject == $subject_row['subject']) ? 'selected' : ''; ?>>
                                <?php echo $subject_row['subject']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary">Apply Filters</button>
                    <a href="<?php echo $_SERVER['PHP_SELF']; ?>" class="btn btn-secondary">Reset Filters</a>
                </div>
            </form>
        </div>
        
        <!-- Question Papers Table -->
        <?php if($result && $result->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Title</th>
                            <th>Department</th>
                            <th>Course Code</th>
                            <th>Year</th>
                            <th>Semester</th>
                            <th>Subject</th>
                            <th>Credits</th>
                            <th>Upload Date</th>
                            <th>Downloads</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $counter = 1;
                        while($row = $result->fetch_assoc()): 
                        ?>
                            <tr>
                                <td><?php echo $counter++; ?></td>
                                <td><?php echo htmlspecialchars($row['title']); ?></td>
                                <td><?php echo htmlspecialchars($row['department']); ?></td>
                                <td><?php echo htmlspecialchars($row['course_code']); ?></td>
                                <td><?php echo htmlspecialchars($row['paper_year']); ?></td>
                                <td><?php echo htmlspecialchars($row['semester']); ?></td>
                                <td><?php echo htmlspecialchars($row['subject']); ?></td>
                                <td><?php echo htmlspecialchars($row['credit']); ?></td>
                                <td><?php echo date('M d, Y', strtotime($row['uploaded_at'])); ?></td>
                                <td><?php echo $row['download_count']; ?></td>
                                <td>
                                    <a href="../download_paper.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-success">View</a>
                                    <a href="delete_paper.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this question paper?')">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="no-papers">
                <h4>No question papers found.</h4>
                <p>Upload a new question paper or change your filter settings.</p>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
// Close connection
$conn->close();
?>