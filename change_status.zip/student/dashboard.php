<?php
session_start();
include('../db_connect.php'); // Changed to include from parent directory

// Check if student is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'student') {
    header("Location: ../index.php"); // Redirect if not a student
    exit();
}

// Initialize search filters
$departments = [];
$subjects = [];
$course_codes = [];
$semesters = [];
$years = [];

// Get all available filter options from database
$dept_query = mysqli_query($conn, "SELECT DISTINCT department FROM question_papers ORDER BY department");
while ($row = mysqli_fetch_assoc($dept_query)) {
    $departments[] = $row['department'];
}

$subj_query = mysqli_query($conn, "SELECT DISTINCT subject FROM question_papers ORDER BY subject");
while ($row = mysqli_fetch_assoc($subj_query)) {
    $subjects[] = $row['subject'];
}

$code_query = mysqli_query($conn, "SELECT DISTINCT course_code FROM question_papers ORDER BY course_code");
while ($row = mysqli_fetch_assoc($code_query)) {
    $course_codes[] = $row['course_code'];
}

$sem_query = mysqli_query($conn, "SELECT DISTINCT semester FROM question_papers ORDER BY semester");
while ($row = mysqli_fetch_assoc($sem_query)) {
    $semesters[] = $row['semester'];
}

$year_query = mysqli_query($conn, "SELECT DISTINCT paper_year FROM question_papers ORDER BY paper_year DESC");
while ($row = mysqli_fetch_assoc($year_query)) {
    $years[] = $row['paper_year'];
}

// Process search filters
$where_conditions = [];
$params = [];

if (isset($_GET['department']) && $_GET['department'] != '') {
    $where_conditions[] = "department = ?";
    $params[] = $_GET['department'];
}

if (isset($_GET['subject']) && $_GET['subject'] != '') {
    $where_conditions[] = "subject = ?";
    $params[] = $_GET['subject'];
}

if (isset($_GET['course_code']) && $_GET['course_code'] != '') {
    $where_conditions[] = "course_code = ?";
    $params[] = $_GET['course_code'];
}

if (isset($_GET['semester']) && $_GET['semester'] != '') {
    $where_conditions[] = "semester = ?";
    $params[] = $_GET['semester'];
}

if (isset($_GET['year']) && $_GET['year'] != '') {
    $where_conditions[] = "paper_year = ?";
    $params[] = $_GET['year'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .search-container {
            background: #f5f5f5;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        
        .search-filters {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 10px;
        }
        
        .filter-group {
            flex: 1;
            min-width: 150px;
        }
        
        .filter-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        .filter-group select {
            width: 100%;
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ddd;
        }
        
        .search-btn {
            background: #4CAF50;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        
        .search-btn:hover {
            background: #45a049;
        }
        
        .reset-btn {
            background: #f44336;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-left: 10px;
        }
        
        .reset-btn:hover {
            background: #d32f2f;
        }
        
        .paper-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .paper-table th, .paper-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        .paper-table th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        
        .paper-table tr:hover {
            background-color: #f5f5f5;
        }
        
        .download-btn {
            background: #2196F3;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            text-decoration: none;
            display: inline-block;
        }
        
        .download-btn:hover {
            background: #0b7dda;
        }

        .dashboard-sections {
            display: grid;
            grid-template-columns: 1fr;
            gap: 20px;
        }
        
        .section {
            background: white;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            padding: 20px;
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        h2 {
            margin: 0;
            color: #333;
        }
        
        .error-message {
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
            border: 1px solid #f5c6cb;
        }
        
        @media (max-width: 768px) {
            .search-filters {
                flex-direction: column;
            }
            
            .filter-group {
                width: 100%;
            }
        }
        .view-btn {
            background: #2196F3;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            text-decoration: none;
            display: inline-block;
            margin-right: 5px;
        }

        .view-btn:hover {
            background: #0b7dda;
        }

        .download-btn {
            background: #4CAF50;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            text-decoration: none;
            display: inline-block;
        }

        .download-btn:hover {
            background: #45a049;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <div class="dashboard-header">
            <h1>Student Dashboard</h1>
            <div class="user-info">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</span>
                <a href="../logout.php" class="logout-btn">Logout</a>
            </div>
        </div>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="error-message">
                <?php 
                    echo $_SESSION['error']; 
                    unset($_SESSION['error']); 
                ?>
            </div>
        <?php endif; ?>

        <div class="dashboard-sections">
            <!-- Question Papers Section with Search -->
            <section class="section">
                <div class="section-header">
                    <h2>Question Papers</h2>
                </div>
                
                <div class="search-container">
                    <form action="" method="GET">
                        <div class="search-filters">
                            <div class="filter-group">
                                <label for="department">Department:</label>
                                <select name="department" id="department">
                                    <option value="">All Departments</option>
                                    <?php foreach ($departments as $dept): ?>
                                        <option value="<?php echo htmlspecialchars($dept); ?>" <?php echo (isset($_GET['department']) && $_GET['department'] == $dept) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($dept); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="filter-group">
                                <label for="subject">Subject:</label>
                                <select name="subject" id="subject">
                                    <option value="">All Subjects</option>
                                    <?php foreach ($subjects as $subj): ?>
                                        <option value="<?php echo htmlspecialchars($subj); ?>" <?php echo (isset($_GET['subject']) && $_GET['subject'] == $subj) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($subj); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="filter-group">
                                <label for="course_code">Course Code:</label>
                                <select name="course_code" id="course_code">
                                    <option value="">All Course Codes</option>
                                    <?php foreach ($course_codes as $code): ?>
                                        <option value="<?php echo htmlspecialchars($code); ?>" <?php echo (isset($_GET['course_code']) && $_GET['course_code'] == $code) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($code); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="filter-group">
                                <label for="semester">Semester:</label>
                                <select name="semester" id="semester">
                                    <option value="">All Semesters</option>
                                    <?php foreach ($semesters as $sem): ?>
                                        <option value="<?php echo htmlspecialchars($sem); ?>" <?php echo (isset($_GET['semester']) && $_GET['semester'] == $sem) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($sem); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="filter-group">
                                <label for="year">Year:</label>
                                <select name="year" id="year">
                                    <option value="">All Years</option>
                                    <?php foreach ($years as $year): ?>
                                        <option value="<?php echo htmlspecialchars($year); ?>" <?php echo (isset($_GET['year']) && $_GET['year'] == $year) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($year); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="search-actions">
                            <button type="submit" class="search-btn">Search</button>
                            <a href="<?php echo $_SERVER['PHP_SELF']; ?>" class="reset-btn">Reset</a>
                        </div>
                    </form>
                </div>
                
                <table class="paper-table">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Department</th>
                            <th>Subject</th>
                            <th>Course Code</th>
                            <th>Semester</th>
                            <th>Year</th>
                            <th>Credits</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Build the SQL query with filters
                        $sql = "SELECT * FROM question_papers";
                        if (!empty($where_conditions)) {
                            $sql .= " WHERE " . implode(" AND ", $where_conditions);
                        }
                        $sql .= " ORDER BY uploaded_at DESC";
                        
                        // Prepare and execute the query
                        $stmt = mysqli_prepare($conn, $sql);
                        
                        if (!empty($params)) {
                            $types = str_repeat('s', count($params));
                            mysqli_stmt_bind_param($stmt, $types, ...$params);
                        }
                        
                        mysqli_stmt_execute($stmt);
                        $result = mysqli_stmt_get_result($stmt);
                        
                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>
                                        <td>" . htmlspecialchars($row['title']) . "</td>
                                        <td>" . htmlspecialchars($row['department']) . "</td>
                                        <td>" . htmlspecialchars($row['subject']) . "</td>
                                        <td>" . htmlspecialchars($row['course_code']) . "</td>
                                        <td>" . htmlspecialchars($row['semester']) . "</td>
                                        <td>" . htmlspecialchars($row['paper_year']) . "</td>
                                        <td>" . htmlspecialchars($row['credit']) . "</td>
                                        <td>
                                            <a href='view_document.php?id=" . $row['id'] . "&type=question_papers' class='view-btn'>View</a>
                                            <a href='download.php?id=" . $row['id'] . "&type=question_papers' class='download-btn'>Download</a>
                                        </td>
                                    </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='8'>No question papers found matching your criteria</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </section>
        </div>
    </div>
</body>
</html>